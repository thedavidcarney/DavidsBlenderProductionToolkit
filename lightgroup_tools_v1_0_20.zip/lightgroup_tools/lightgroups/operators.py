import bpy

from ..core.tags import FESTOON_BULB_SOURCE, FESTOON_STRAND


class LIGHTGROUP_OT_clear_all_lightgroups(bpy.types.Operator):
    """Delete all lightgroups from the current view layer"""
    bl_idname = "lightgroup.clear_all_lightgroups"
    bl_label = "Clear All Lightgroups"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        lightgroups = context.view_layer.lightgroups
        lightgroup_count = len(lightgroups)
        
        if lightgroup_count == 0:
            self.report({'INFO'}, "No lightgroups to clear")
            return {'FINISHED'}
        
        # Remove all lightgroups (iterate backwards to avoid index issues)
        for i in range(lightgroup_count - 1, -1, -1):
            lightgroups.remove(lightgroups[i])
        
        self.report({'INFO'}, f"Cleared {lightgroup_count} lightgroup(s)")
        return {'FINISHED'}


class LIGHTGROUP_OT_create_for_each_light(bpy.types.Operator):
    """Create a lightgroup for each light, world, and emissive object"""
    bl_idname = "lightgroup.create_for_each_light"
    bl_label = "Create Lightgroups"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        lightGroupsAmount = 0
        lightGroupsNames = []

        # Get all the lights in the scene
        lights = [obj for obj in context.scene.objects if obj.type == 'LIGHT']

        # Create a light group for each light and assign the light to it
        for i, light in enumerate(lights):
            oldName = light.name
            newName = oldName.replace(".", "_")
            
            # Create a new light group in the view layer tab
            bpy.ops.scene.view_layer_add_lightgroup(name=newName)
            
            # Assign the light to the new group directly
            light.lightgroup = newName
            
            # Increment our light group counter and add name to the list
            lightGroupsAmount += 1
            lightGroupsNames.append(newName)
            
        # Make a new lightgroup for world
        bpy.ops.scene.view_layer_add_lightgroup(name="World")
        # Assign World to world lightgroup
        context.scene.world.lightgroup = "World"
        # Increment our light group counter and add name to the list
        lightGroupsAmount += 1
        lightGroupsNames.append("World")

        emissive_materials = []
        emissive_objects = []

        # Loop through all the materials in the scene
        for material in bpy.data.materials:
            if not material.use_nodes:
                continue
            
            # Loop through all the nodes in the material's node tree
            for node in material.node_tree.nodes:
                # Check if the node is an Emission shader
                if node.type == 'EMISSION':
                    color_socket = node.inputs[0] if len(node.inputs) > 0 else None
                    strength_socket = node.inputs[1] if len(node.inputs) > 1 else None

                    has_strength = strength_socket and strength_socket.default_value > 0
                    has_strength_connection = strength_socket and strength_socket.is_linked
                    has_color_connection = color_socket and color_socket.is_linked

                    # Check if emission color is not black (0,0,0)
                    has_nonzero_color = False
                    if color_socket and not color_socket.is_linked:
                        color = color_socket.default_value
                        has_nonzero_color = any(c > 0.001 for c in color[:3])

                    # Same logic as the Principled BSDF path: only emissive if strength > 0
                    # AND (color is non-black OR color is connected), OR strength is connected
                    if (has_strength and (has_nonzero_color or has_color_connection)) or has_strength_connection:
                        if material.name not in emissive_materials:
                            emissive_materials.append(material.name)
                            print(f"Found Emissive Mat: {material.name}")
                        break

        # Check Principled BSDF for emission
        for material in bpy.data.materials:
            if not material.use_nodes:
                continue
            
            for node in material.node_tree.nodes:
                if node.type == 'BSDF_PRINCIPLED':
                    # Find emission sockets by name (more reliable than index)
                    emission_socket = None
                    emission_strength_socket = None
                    
                    for input_socket in node.inputs:
                        if input_socket.name == "Emission Color":
                            emission_socket = input_socket
                        elif input_socket.name == "Emission Strength":
                            emission_strength_socket = input_socket
                    
                    # Check if emission strength > 0
                    has_emission_strength = emission_strength_socket and emission_strength_socket.default_value > 0
                    
                    # Check if emission color is not black (0,0,0)
                    has_nonzero_color = False
                    if emission_socket and not emission_socket.is_linked:
                        color = emission_socket.default_value
                        has_nonzero_color = any(c > 0.001 for c in color[:3])  # Check RGB, ignore alpha
                    
                    # Check connections
                    has_emission_connection = emission_strength_socket and emission_strength_socket.is_linked
                    has_color_connection = emission_socket and emission_socket.is_linked
                    
                    # Only consider emissive if strength > 0 AND (color is non-black OR color is connected)
                    # OR if strength socket is connected
                    if (has_emission_strength and (has_nonzero_color or has_color_connection)) or has_emission_connection:
                        # Avoid duplicates
                        if material.name not in emissive_materials:
                            emissive_materials.append(material.name)
                            print(f"Found Principled BSDF Mat with emission: {material.name}")
                        break

        # Print out the list of materials that use emission
        print(f"Total emissive materials found: {len(emissive_materials)}")
        print(emissive_materials)

        # Find objects using emissive materials
        for obj in bpy.data.objects:
            # Check if object has material slots
            if not hasattr(obj, 'material_slots'):
                continue

            # Skip objects that exist only to be instanced. A festoon bulb
            # source has emissive materials but is excluded from the view layer
            # and never renders itself -- a lightgroup per bulb part would be
            # pure noise in the compositor.
            if obj.get(FESTOON_BULB_SOURCE):
                continue
            
            # Iterate through all material slots
            for slot in obj.material_slots:
                # Handle missing materials (null check)
                if slot.material is None:
                    continue
                
                # Check if material name is in material_list
                if slot.material.name in emissive_materials:
                    # Avoid duplicate objects
                    if obj not in emissive_objects:
                        print(f"Found Object using Emission: {obj.name}")
                        emissive_objects.append(obj)
                    break

        # Objects that emit through INSTANCING rather than their own material
        # slots. A festoon strand instances its bulbs, so the strand mesh has no
        # material slots at all and the scan above cannot see it -- every strand
        # in the scene would silently end up with no lightgroup, and the denoise
        # setup would then build a compositor missing those passes entirely.
        # They carry a tag for exactly this reason.
        for obj in bpy.data.objects:
            if obj.get(FESTOON_STRAND) and obj not in emissive_objects:
                print(f"Found instanced emitter (festoon strand): {obj.name}")
                emissive_objects.append(obj)

        # Create a light group for each emissive object and assign it
        for i, emissive_object in enumerate(emissive_objects):
            oldName = emissive_object.name
            newName = oldName.replace(".", "_")
            
            # Create a new light group in the view layer tab
            bpy.ops.scene.view_layer_add_lightgroup(name=newName)
            
            # Assign the object to the new group directly
            emissive_object.lightgroup = newName
            
            # Increment our light group counter and add name to the list
            lightGroupsAmount += 1
            lightGroupsNames.append(newName)

        print(f"\nTotal lightgroups created: {lightGroupsAmount}")
        print(f"Lightgroup names: {lightGroupsNames}")
        
        self.report({'INFO'}, f"Created {lightGroupsAmount} lightgroups")
        return {'FINISHED'}


# Render Layers outputs that never belong in the single EXR: the noisy beauty
# is superseded by the denoised one. Every "Denoising ..." pass is skipped by
# prefix further down -- 5.x keeps adding new ones (Specular Albedo, Roughness)
# and they are all denoiser fodder.
#
# Alpha stays, even though Image.A holds the true alpha. The team template uses
# this layer's RGB as a Stencil Luma (measured by PostPost on the ambient chase),
# and a missing layer blanks those comps in AE without an error.
SINGLE_EXR_SKIP = {"Noisy Image", "Noisy Shadow Catcher"}


def setup_single_exr(operator, context):
    """5.2+: denoised lightgroups, beauty and every other pass in ONE EXR.

    The older setup leaves the scene's render output on, so every animation
    frame is written twice: the File Output EXR, plus the render output dumping
    every view-layer pass a second time. Nobody knew which file was the real
    one. Here the File Output node is the only writer. `render.save_output`
    does not exist before 5.2, which is why this is version-gated.

    Every item stays RGBA on purpose: the team uses Mist stylistically and
    doesn't need exact values. Typing Depth, Mist and Normal as FLOAT or VECTOR
    would stop Filmic touching them, but EXRDemux only reads R/G/B/A and would
    load them as opaque black, and DWAB is still lossy on their .Y channel.
    Crypto needs nothing: 5.2 already writes it bit-exact, as float.
    """
    scene = context.scene
    viewLayer = context.view_layer
    lightGroupsNames = [lg.name for lg in viewLayer.lightgroups]

    viewLayer.cycles.denoising_store_passes = True
    # The File Output node only runs if the compositor does.
    scene.render.use_compositing = True

    tree = scene.compositing_node_group
    if tree is None:
        tree = bpy.data.node_groups.new(name="Compositor", type='CompositorNodeTree')
        scene.compositing_node_group = tree

    # The compositor is rebuilt from scratch, so a File Output left over from
    # an older setup can't keep writing a 2nd file.
    for node in list(tree.nodes):
        tree.nodes.remove(node)
    links = tree.links

    renderLayersNode = tree.nodes.new(type='CompositorNodeRLayers')
    renderLayersNode.location = 0, 0
    # A new Render Layers node defaults to the scene's FIRST view layer, not
    # the active one, so pin it.
    renderLayersNode.scene = scene
    renderLayersNode.layer = viewLayer.name
    outputs = {o.name: o for o in renderLayersNode.outputs if o.enabled}

    albedo = outputs.get("Denoising Albedo")
    normal = outputs.get("Denoising Normal")
    if albedo is None or normal is None:
        operator.report({'ERROR'}, f"Denoising outputs not found on view layer '{viewLayer.name}'. Enable 'Denoising Data' in its Passes settings.")
        return {'CANCELLED'}

    def add_denoise(source, y):
        denoiseNode = tree.nodes.new(type='CompositorNodeDenoise')
        denoiseNode.location = 500, y
        links.new(source, denoiseNode.inputs["Image"])
        links.new(albedo, denoiseNode.inputs["Albedo"])
        links.new(normal, denoiseNode.inputs["Normal"])
        return denoiseNode.outputs["Image"]

    outputNode = tree.nodes.new(type='CompositorNodeOutputFile')
    outputNode.directory = "//../../04_Renders/01_Components/"
    outputNode.file_name = "{blend_name}_"
    outputNode.location = 1000, -250
    outputNode.width = 500

    fmt = outputNode.format
    fmt.media_type = 'MULTI_LAYER_IMAGE'
    fmt.file_format = 'OPEN_EXR_MULTILAYER'
    fmt.color_depth = '16'
    fmt.exr_codec = 'DWAB'
    fmt.quality = 15
    fmt.color_management = 'OVERRIDE'
    # Last, and read back: a wrong colour space here would quietly change the
    # brightness of every pass in AE.
    fmt.linear_colorspace_settings.name = 'Filmic sRGB'
    if fmt.linear_colorspace_settings.name != 'Filmic sRGB':
        operator.report({'ERROR'}, f"Output colour space stuck at '{fmt.linear_colorspace_settings.name}', expected Filmic sRGB")
        return {'CANCELLED'}

    def add_layer(name, source):
        outputNode.file_output_items.new('RGBA', name=name)
        links.new(source, outputNode.inputs[len(outputNode.file_output_items) - 1])

    used = {"Image", "Denoising Albedo", "Denoising Normal"}
    y = 0

    # Lightgroups, denoised one by one.
    for name in lightGroupsNames:
        source = outputs.get(f"Combined_{name}")
        used.add(f"Combined_{name}")
        if source is None:
            print(f"WARNING: Could not find output for light group 'Combined_{name}'")
            continue
        add_layer(name, add_denoise(source, y))
        y -= 250

    # Beauty. Image is only already denoised when BOTH the scene and this view
    # layer have render denoising on; otherwise denoise it here, so the file
    # never holds a noisy beauty.
    beauty = outputs["Image"]
    if not (scene.cycles.use_denoising and viewLayer.cycles.use_denoising):
        beauty = add_denoise(beauty, y)
    add_layer("Image", beauty)

    # Show the same beauty in the render window.
    if not any(item.item_type == 'SOCKET' and item.in_out == 'OUTPUT' for item in tree.interface.items_tree):
        tree.interface.new_socket("Image", in_out='OUTPUT', socket_type='NodeSocketColor')
    groupOutputNode = tree.nodes.new(type='NodeGroupOutput')
    groupOutputNode.location = 1000, 250
    links.new(beauty, groupOutputNode.inputs[0])

    # Depth, Crypto, AOVs and any other enabled pass.
    extras = []
    for output in renderLayersNode.outputs:
        if (not output.enabled or output.name in used or output.name in SINGLE_EXR_SKIP
                or output.name.startswith("Denoising ")):
            continue
        add_layer(output.name, output)
        extras.append(output.name)

    # The File Output node is now the only thing that writes frames.
    scene.render.save_output = False

    print(f"Single EXR: {lightGroupsNames} + Image + {extras}")
    operator.report({'INFO'}, f"Single EXR: {len(lightGroupsNames)} denoised lightgroups + Image + {len(extras)} passes. Render output turned off.")
    return {'FINISHED'}


class LIGHTGROUP_OT_denoise_all_cycles(bpy.types.Operator):
    """Set up compositor to denoise all lightgroups (Cycles only)"""
    bl_idname = "lightgroup.denoise_all_cycles"
    bl_label = "Setup Denoise Compositor"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Check if Cycles is the active render engine
        if context.scene.render.engine != 'CYCLES':
            self.report({'ERROR'}, "This script requires Cycles render engine. Please switch to Cycles and try again.")
            return {'CANCELLED'}

        # 5.2+ writes everything through one File Output and turns the render
        # output off. Older versions keep the original two-file setup below.
        if bpy.app.version >= (5, 2, 0):
            return setup_single_exr(self, context)
        
        # SET UP COMPOSITOR
        # Prep lightgroups variables
        # Use the active view layer rather than a hardcoded name, so this works
        # in scenes where the view layer was renamed or there are several.
        viewLayer = context.view_layer
        lightGroups = viewLayer.lightgroups
        lightGroupsAmount = len(lightGroups)
        lightGroupsNames = []
        i = 0
        while i < lightGroupsAmount:
            lightGroupsNames.append(lightGroups[i].name)
            i += 1
            
        print(lightGroupsNames)
        
        # Make sure compositor nodes are on
        scene = context.scene
        viewLayer.cycles.denoising_store_passes = True
        
        # Handle both Blender 4.5 and 5.0
        tree = None
        if hasattr(scene, 'compositing_node_group'):
            # Blender 5.0+
            tree = scene.compositing_node_group
            
            # If no tree exists, create one
            if tree is None:
                tree = bpy.data.node_groups.new(name="Compositor", type='CompositorNodeTree')
                scene.compositing_node_group = tree
                print("Created new compositor tree for Blender 5.0")
        else:
            # Blender 4.5 and earlier
            scene.use_nodes = True
            tree = scene.node_tree
        
        # Final safety check
        if tree is None:
            self.report({'ERROR'}, "Could not access or create compositor node tree")
            return {'CANCELLED'}
        
        # Clear all previous nodes so we can control where they are
        for node in tree.nodes:
            tree.nodes.remove(node)
            
        renderLayersNode = tree.nodes.new(type='CompositorNodeRLayers')
        renderLayersNode.location = 0, 0
        # A new Render Layers node defaults to the scene's FIRST view layer, not the
        # active one. In scenes with multiple view layers that means it reads sockets
        # from the wrong layer (missing Denoising Data / lightgroups), so pin it.
        renderLayersNode.scene = scene
        renderLayersNode.layer = viewLayer.name
        links = tree.links
        
        # Helper function to find output by name
        def find_output(node, output_name):
            for output in node.outputs:
                if output.name == output_name:
                    return output
            return None
        
        # Find the denoising outputs by name
        denoisingNormalOutput = find_output(renderLayersNode, "Denoising Normal")
        denoisingAlbedoOutput = find_output(renderLayersNode, "Denoising Albedo")
        
        # Check if denoising outputs exist
        if not denoisingNormalOutput or not denoisingAlbedoOutput:
            print(f"ERROR: Denoising outputs not found on view layer '{viewLayer.name}'. Make sure 'Denoising Data' is enabled in the Passes panel for that view layer.")
            self.report({'ERROR'}, f"Denoising outputs not found on view layer '{viewLayer.name}'. Enable 'Denoising Data' in its Passes settings.")
            return {'CANCELLED'}
        
        # Create Output Node
        outputNode = tree.nodes.new(type='CompositorNodeOutputFile')
        # Handle both Blender 4.5 and 5.0 attribute names
        if hasattr(outputNode, 'base_path'):
            # Blender 4.5 and earlier
            outputNode.base_path = "//../../04_Renders/01_Components/{blend_name}_"
        else:
            # Blender 5.0+ uses directory and file_name separately
            outputNode.directory = "//../../04_Renders/01_Components/"
            outputNode.file_name = "{blend_name}_"
        outputNode.location = 1000, -250
        outputNode.width = 500
        
        # Configure EXR format settings
        outputNode.format.file_format = 'OPEN_EXR_MULTILAYER'
        outputNode.format.color_depth = '16'  # Float (half)
        outputNode.format.exr_codec = 'DWAB'
        outputNode.format.quality = 15  # Quality 15%
        outputNode.format.color_management = 'OVERRIDE'
        outputNode.format.linear_colorspace_settings.name = 'Filmic sRGB'
        
        # Track which outputs we've already used
        usedOutputs = set()
        
        # Current slot index for file output
        slotIndex = 0
        
        # Process light groups with denoising
        i = 0
        while i < lightGroupsAmount:
            denoiseNode = tree.nodes.new(type='CompositorNodeDenoise')
            denoiseNode.location = 500, i * -250
            
            # Find the light group output by name with "Combined_" prefix
            lightGroupOutputName = f"Combined_{lightGroupsNames[i]}"
            lightGroupOutput = find_output(renderLayersNode, lightGroupOutputName)
            
            if lightGroupOutput and denoisingNormalOutput and denoisingAlbedoOutput:
                # Track that we're using these outputs
                usedOutputs.add(lightGroupOutputName)
                usedOutputs.add("Denoising Normal")
                usedOutputs.add("Denoising Albedo")
                
                # link the image to denoise
                links.new(lightGroupOutput, denoiseNode.inputs[0])
                
                # link the denoising data
                links.new(denoisingAlbedoOutput, denoiseNode.inputs[1])
                links.new(denoisingNormalOutput, denoiseNode.inputs[2])
                
                # link the denoiser to file output
                # Handle both Blender 4.5 and 5.0 slot naming
                if hasattr(outputNode, 'layer_slots'):
                    # Blender 4.5 and earlier
                    if slotIndex == 0:
                        outputNode.layer_slots[0].name = lightGroupsNames[i]
                        links.new(denoiseNode.outputs[0], outputNode.inputs[slotIndex])
                    else:
                        outputNode.layer_slots.new(lightGroupsNames[i])
                        links.new(denoiseNode.outputs[0], outputNode.inputs[slotIndex])
                else:
                    # Blender 5.0+ uses file_output_items (requires socket type and name)
                    outputNode.file_output_items.new('RGBA', name=lightGroupsNames[i])
                    links.new(denoiseNode.outputs[0], outputNode.inputs[slotIndex])
                
                slotIndex += 1
            else:
                print(f"WARNING: Could not find output for light group '{lightGroupOutputName}'")
            
            i += 1
        
        # Now add all remaining passes (except Denoising Depth) directly to file output
        for output in renderLayersNode.outputs:
            # Skip if we've already used this output, or if it's Denoising Depth, or if it's not enabled
            if output.name in usedOutputs or output.name == "Denoising Depth" or output.name == "Noisy Image" or not output.enabled:
                continue
            
            # Add this pass to the file output
            # Handle both Blender 4.5 and 5.0 slot naming
            if hasattr(outputNode, 'layer_slots'):
                # Blender 4.5 and earlier
                if slotIndex == 0:
                    outputNode.layer_slots[0].name = output.name
                    links.new(output, outputNode.inputs[slotIndex])
                else:
                    outputNode.layer_slots.new(output.name)
                    links.new(output, outputNode.inputs[slotIndex])
            else:
                # Blender 5.0+ uses file_output_items (requires socket type and name)
                outputNode.file_output_items.new('RGBA', name=output.name)
                links.new(output, outputNode.inputs[slotIndex])
            
            slotIndex += 1
            print(f"Added pass: {output.name}")
        
        self.report({'INFO'}, "Compositor setup complete")
        return {'FINISHED'}


class LIGHTGROUP_OT_assign_to_lightgroup(bpy.types.Operator):
    """Assign selected objects and lights to a lightgroup"""
    bl_idname = "lightgroup.assign_to_lightgroup"
    bl_label = "Add Selected to Lightgroup"
    bl_options = {'REGISTER', 'UNDO'}
    
    def get_lightgroup_items(self, context):
        """Generate enum items from existing lightgroups"""
        items = []
        
        # Add "New Lightgroup" option at the top
        items.append(('NEW', 'New Lightgroup...', 'Create a new lightgroup'))
        
        # Get existing lightgroups from the active view layer
        try:
            lightgroups = context.view_layer.lightgroups
            for lg in lightgroups:
                items.append((lg.name, lg.name, f"Assign to {lg.name}"))
        except Exception as e:
            print(f"Error getting lightgroups: {e}")
        
        # Enum must have at least one item
        if len(items) == 0:
            items.append(('NONE', 'No Lightgroups', 'No lightgroups available'))
        
        return items
    
    # Enum property for lightgroup selection
    lightgroup_enum: bpy.props.EnumProperty(
        name="Lightgroup",
        description="Select a lightgroup to assign objects to",
        items=get_lightgroup_items
    )
    
    # String property for new lightgroup name
    new_lightgroup_name: bpy.props.StringProperty(
        name="New Lightgroup Name",
        description="Name for the new lightgroup",
        default="Lightgroup"
    )
    
    def invoke(self, context, event):
        """Show dialog when operator is invoked"""
        # Check if anything is selected
        if not context.selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        # Check if there are any lightgroups
        lightgroups = context.view_layer.lightgroups
        if len(lightgroups) == 0:
            # No lightgroups exist, go straight to creating a new one
            return context.window_manager.invoke_props_dialog(self)
        
        # Show the dropdown dialog
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        """Draw the dialog UI"""
        layout = self.layout
        
        lightgroups = context.view_layer.lightgroups
        
        if len(lightgroups) == 0:
            # No lightgroups - just show name input
            layout.label(text="No lightgroups exist. Create one:")
            layout.prop(self, "new_lightgroup_name", text="Name")
        else:
            # Show dropdown with all options including "New Lightgroup..."
            layout.label(text="Select Lightgroup:")
            layout.prop(self, "lightgroup_enum", text="")
            
            # If "New Lightgroup" is selected, show name input
            if self.lightgroup_enum == 'NEW':
                layout.separator()
                layout.label(text="Create New:")
                layout.prop(self, "new_lightgroup_name", text="Name")
    
    def execute(self, context):
        """Execute the assignment"""
        selected_objects = context.selected_objects
        
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        # Determine which lightgroup to use
        lightgroups = context.view_layer.lightgroups
        target_lightgroup = None
        
        if len(lightgroups) == 0 or self.lightgroup_enum == 'NEW':
            # Create new lightgroup
            lightgroup_name = self.new_lightgroup_name.strip()
            if not lightgroup_name:
                self.report({'ERROR'}, "Lightgroup name cannot be empty")
                return {'CANCELLED'}
            
            # Replace periods with underscores for consistency
            lightgroup_name = lightgroup_name.replace(".", "_")
            
            bpy.ops.scene.view_layer_add_lightgroup(name=lightgroup_name)
            target_lightgroup = lightgroup_name
            self.report({'INFO'}, f"Created new lightgroup: {lightgroup_name}")
        else:
            target_lightgroup = self.lightgroup_enum
        
        # Assign selected objects to the lightgroup
        assigned_count = 0
        skipped_count = 0
        
        for obj in selected_objects:
            try:
                # Check if object can have a lightgroup assigned
                if hasattr(obj, 'lightgroup'):
                    obj.lightgroup = target_lightgroup
                    assigned_count += 1
                else:
                    skipped_count += 1
            except Exception as e:
                print(f"Could not assign {obj.name} to lightgroup: {e}")
                skipped_count += 1
        
        # Report results
        if assigned_count > 0:
            self.report({'INFO'}, f"Assigned {assigned_count} object(s) to '{target_lightgroup}'")
        
        if skipped_count > 0:
            self.report({'WARNING'}, f"Skipped {skipped_count} object(s) that cannot be assigned to lightgroups")
        
        return {'FINISHED'}
